#!/bin/bash

echo -n "Enter the number: "
read num

while [ $num -lt 10 ]
		do
				echo number is less than 10
				let num=$num+1
				done
				

