<<comment
Title : Shell script to lock permissions
Date  : 29-07-2019
Author: karthik
input : directory name
output: display permissions
comment

n=$1
if [ $# -eq 1 ]                                                                        # check the condition for argument
then
		cd $n       #to change the directory to n vallue
	echo "before locking "                  ls -l
	for i in *           #all file
do
		chmod go-rwx $i       #to add multiple permission
done
else
		echo error:enter the directory
fi
echo check the directory
ls -l
