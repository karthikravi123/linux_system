#!/bin/bash

echo -n "enter the num : "
read num1 num2

sum=$( ($num1 + $num2))
echo sum is $sum

