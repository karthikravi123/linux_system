#!/bin/bash

echo "enter the a and b:"
read a b

if [ `expr $b % $a` -eq 0 ]
		then
		echo its multiple nu
		else
				echo not a multiple nu
				fi
