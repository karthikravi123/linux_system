#!/bin/bash

echo num1 "enter the length:"
read num1
echo num2 "enter the breadth"
read num2
if [ $num1 -eq $num2 ]
then 
	echo its a SQUARE 	
	else 
	echo its a rectangle
	fi 
		
	 
