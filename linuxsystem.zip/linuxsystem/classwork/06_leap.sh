#!/bin/bash

echo "enter the year : "
read year
var1=$(($year % 4))
var2=$(($year % 100))
var3=$(($year % 400))
if [ `$(($year % 4)) -o $(($year % 100)) -o $(($year % 400))` -eq 0 ]
		then 
		echo leap year
		else
				echo not leap yr
				fi

