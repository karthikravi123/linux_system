#!/bin/bash

echo "enter the no:"
read n

if [ `expr $n % 2` -ne 0 ]
		then 
		echo  its prime
		else
				echo not prime
				fi

