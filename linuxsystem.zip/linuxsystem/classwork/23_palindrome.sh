#!/bin/bash

echo -n  enter the nu to check
read n
rev=0
temp=$n

while [ $n -ne 0 ]
		do
      x=$(( $n%10 ))
	  n=$(( $n / 10 ))
      y=$(( $rev * 10 ))
	  rev=$(( $y + $x ))
	  done
	  echo $rev
if [ $temp -eq $rev ]
			  then 
			  echo its a plind
			  else
					  echo not a palind
					  fi
