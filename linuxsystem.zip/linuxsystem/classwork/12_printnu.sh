#!/bin/bash

for i in $(seq 1 100)
do
		echo  -n $i
		done

