#i/bin/bash
echo enter value of n
read n
k=1
for ((i=1;i<=n;i++))
		do
				for ((j=1;j<=i;j++,k++))
						do
								a=`expr $k % 2 `
								if [ $a -eq 0 ]
										then
										echo -n " 0"
										else
									 echo -n " 1"
									 fi
									 done
									 echo -e " "
									 done
								
