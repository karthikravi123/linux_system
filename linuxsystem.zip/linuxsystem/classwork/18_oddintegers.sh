#!/bin/bash

echo -n "enter the value of m and n "
read m n
sum=0

for i in $(seq $m $n)
		do
				a=`expr $m % 2`
				if [ $a -ne 0 ]
		       then
				sum=$(( $sum  + $i  ))
				fi
				done
				echo $sum
				
