#!/bin/bash

echo  -n enter n:
read n
sum=0
while [ $n -ne 0 ]
		do
				d=`expr $n % 10 `
				sum=`expr $sum + $d`
				n=`expr $n / 10`
				done
				echo $sum
				 
