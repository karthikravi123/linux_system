 #!/bin/bash

 echo "enter num of time hello world to be printed "
 
 read n
i=1
while [ $i -le $n ]
		do 
				echo hello world 
				i=$(($i + 1))
		  done
