#!/bin/bash

for i in $(seq 1 100)
		do
			a=`expr $i % 2`
			if [ $a -eq 0 ]
					then 
					echo -n , $i
					fi 
				done
