#!/bin/bash

echo -n "enter the num: "

read num 
if [ $num -ge 30 ]
then
if [ $num -le 40 ]
then 
echo num is btw 30 and 40
else
	echo num is not btw 30 and 40
fi
else
	echo num is less then 30
fi



	
