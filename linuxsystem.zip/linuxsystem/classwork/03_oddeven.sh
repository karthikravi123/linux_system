#!/bin/bash

echo "enter a num1: "
read num1
echo "enter a num2: "
read num2
 let num=$((num1*num2))
 echo product: $num

 if [ `expr $num % 2` = 0 ]
	then 
	 echo "product is even "
else
 echo "product is odd"
		 fi 
