#!/bin/bash

echo "enter marks of sub1 sub2 sub3 :"
read sub1 sub2 sub3
let total=$(($sub1+$sub2+$sub3))
echo $total
if [ $total -gt 100 ]
		then
		echo excell
		elif [ $total -gt 50 -a $total -lt 100 ] 
			then
				echo avg
		else
				echo fail
				fi

				
		


