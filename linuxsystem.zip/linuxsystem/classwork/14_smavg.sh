#!/bin/bash
echo  -n  enter the value of n
read n
sum=0

for (( i=1;i<=n;i++ ))
		do
				sum=$(( $sum + $i ))
				done
				echo $sum
				avg=$(( $sum / $n ))
				echo $avg

