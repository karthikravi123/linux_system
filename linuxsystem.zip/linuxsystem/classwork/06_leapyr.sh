#!/bin/bash

echo "enter the year:"
read a
p=$(($a % 400))
q=$(($a % 100))
r=$(($a % 4))

if [ $p -eq 0 -o $r -eq 0 -a $q -ne 0 ]
		then 
		echo leap yr
		else
			echo not leap ye
fi

