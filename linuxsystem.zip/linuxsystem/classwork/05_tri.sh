#!/bin/bash

echo " Enter value of a b c: "
		read a b c
		p=$(($(($a*$a)) + $(($b*$b))))
q=$(($c * $c))
		if [ $p -ge $q ]
		then 
		echo its right ang tri
		else
		echo its not right ang tri
		fi

