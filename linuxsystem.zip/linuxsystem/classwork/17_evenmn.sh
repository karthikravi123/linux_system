#!/bin/bash
echo enter the value of m n
read m n

for ((i=m;i<=n;i++))
		
		do
			if [ `expr $i % 2 ` -eq 0  ]
					then
					echo -n "$i "
					fi
			#	m=$(($m+1))	
				done
				
				

