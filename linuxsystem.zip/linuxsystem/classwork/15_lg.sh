#!/bin/bash

echo "enter the no of element "
read n

echo "enter value of array"
for ((i=0;i<n;i++))
do
echo enter the value of element  
read arr[$i]
done
min=${arr[0]}
max=${arr[0]}

for ((i=0;i<n;i++))
do
if [ ${arr[$i]} -gt $max ]
then
max=${arr[$i]}
fi
if [ ${arr[$i]} -lt $min ]
then
min=${arr[$i]}
fi
done

echo The Largest $max
echo The Smallest $min


