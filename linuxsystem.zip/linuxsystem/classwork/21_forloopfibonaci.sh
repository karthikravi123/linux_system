#!/bin/bash

echo enter value
read n
a=0 b=1

for ((i=1;i<n;i++))
		do
				c=$(($a + $b))
				a=$b
				b=$c
				echo  $c
				done
