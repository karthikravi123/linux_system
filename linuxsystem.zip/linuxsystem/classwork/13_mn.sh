#!/bin/bash
echo enter the value of m n
read m n
for i in $(seq $m $n)
		
		do
				echo $i
				m=$(($m+1))
				done

