#!/bin/bash

echo " Enter a number"
read num

if [ `expr $num % 5 ` ]
		then 
echo number is divided by 5
else 
		echo it is not divided by 5
		fi

