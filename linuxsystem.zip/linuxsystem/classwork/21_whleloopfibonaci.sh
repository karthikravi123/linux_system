#!/bin/bash

echo "enter the value"
read n
a=0 b=1 
i=1
echo fibonaci series $b
while [ $i -lt $n ]
		do
				c=$(($a + $b))
				a=$b
				b=$c
i=$(($i + 1))
				echo $c 
				done


