#!/bin/bash
echo -n enter the value of n
read n
sum=0
for i in $(seq 1 $n)
do	
		sum=$(( $sum + $i ))	
			done
			echo $sum
avg=$(( $sum / $n ))
	echo $avg	
	
