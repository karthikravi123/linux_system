#i/bin/bash
echo enter value of n
read n
k=1
for ((i=1;i<=n;i++))
		do
				for ((j=1;j<=i;j++,k++))
						do
								echo  -n  " $k"
								done
								echo  -e  " "
								done
								
