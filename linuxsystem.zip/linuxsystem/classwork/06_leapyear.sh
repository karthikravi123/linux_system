#!/bin/bash

echo "enter the year:"
read yr
p=$[ $yr % 400 ]
q=$[ $yr % 100 ]
r=$[ $yr % 4 ]

if [ $q -a $r -eq 0 ]
		then
		if [ $p -eq 0] 
				then
		echo leap year
		else
				echo not leap yr
				fi
else
		echo -n "NOT LEAP YEAR"
		fi

