#i/bin/bash
echo enter value of n
read n
for ((i=1;i<=n;i++))
		do
				for ((j=1;j<=i;j++))
						do
								echo -n " "
								done
								for ((k=i;k<=n;k++))
										do
								echo  -n  "*"
								done
								echo  -e  " "
								done
								
