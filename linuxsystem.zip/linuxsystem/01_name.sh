#!/bin/bash

echo -n "enter the name: "
read name

echo name is $name

