#!/bin/bash


for i in 1 2 3 4 5 
		do 
				echo loop is at $i
				done
