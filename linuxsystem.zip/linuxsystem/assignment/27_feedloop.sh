<<comment
title:infinite feed loop
date:23.7.19
author:karthik
input:hai hello
output:hai hello
       hai hello
comment

#!/bin/bash
echo enter the before loop files content
tail -1 hello.txt
echo after loop filter content
tail -n 1 -f hello.txt >> hello.txt | tail -f hello.txt

