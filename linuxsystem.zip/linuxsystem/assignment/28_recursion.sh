#!/bin/bash


arr=[$1]

if [ $# -eq 0 ]
then
		echo enter valid argument
else
		echo

