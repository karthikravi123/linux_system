#!/bin/bash
echo  enter the value
read n
for ((i=1;i<=n;i++))
do
	for ((j=1;j<=i;j++))
		do
s=$((i + j))
sum=$(($s % 2))

if [ $sum -eq 0 ]
	then
	echo -n "1"
	else
	echo -n "0"
	fi
done	
echo -e " " 
echo
done


