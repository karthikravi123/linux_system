#!/bin/bash

arr=(`cat /dev/urandom | cut -d: -f1-6`)
echo $arr
