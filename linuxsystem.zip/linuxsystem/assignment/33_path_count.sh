<<comment
write script to display number of executable file
date:27/07/2019
author:karthik
input:file direction
output:count of executable files
comment
#!/bin/bash

c=$PATH                          #assign path variable to another variable
a=`echo $c | tr  ":" " " `       #deleting the symbol    

arr=($a)                           #assigning to array
count=0                          
l=`expr ${#arr[@]} - 1 `              #length
for  i in `seq 0 $l` 
do                                                   
		echo current location : ${arr[$i]}              #this for directory
                                    
		cd ${arr[$i]}
		for j in *                           #taking contents of directory
		do

	if [ -x  $j ]      #condition  to check it is executable file are not  
	then
		count=`expr $count + 1`      #count the executable file


				fi
		done

		echo count : $count          

done #end of loop


