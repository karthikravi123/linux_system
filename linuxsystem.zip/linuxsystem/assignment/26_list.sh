<<comment
title:to list directory
author:karthik
date:25.7.19
input:
output:
comment




#!/bin/bash
if [ $# -eq 0 ]            #condition for argument
then
		echo no argument passed
		echo  present directory `dir $@`	
else
       dir "$1"  #to list directory
fi

