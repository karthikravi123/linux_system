<<coment
#title:write a script to print a chess board
#date:22.7.19
#author:karthik
#input:
#output:
coment


#!/bin/bash

for i in $(seq 1 8)  #loop for row till value i
do
	for j in $(seq 1 8)  #loop for coloumn till value j
		do
s=$((i + j))
sum=$(($s % 2))

if [ $sum -eq 0 ]         #condition  if loop to print chess board
	then                               
	echo -e -n "\e[40m" " "
	else
	echo -e -n "\e[47m" " "
	fi
done	
echo -e -n "\e[0m" " "
echo
done


