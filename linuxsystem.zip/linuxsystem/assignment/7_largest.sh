<<coment
#title:write a script to compare largest value from a n number using CLI
#author:karthik
#date:22.7.19
#input:5 6 8 4 2
#output:8
#!/bin/bash
coment

#echo array element recieved
#arr=($@)     #to store the value in array
#l=`expr ${#arr[@]} - 1`
#echo `expr $l + 1 `
#max=${arr[0]}  
large=$1
if [ $# -eq 0 ]
then
		echo  enter valid argument
else
		
		for i in $@  #for  loop used to the iteration
		do
				#echo
				#echo
				#echo "${arr[$i]}"
				if [ $i -gt $large ]  #if condition to check for max value
				then
		large=$i
else 
		large=$large
				fi

		done
echo the largest vlaue is $large
fi

