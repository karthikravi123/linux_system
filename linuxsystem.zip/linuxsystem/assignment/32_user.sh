<<comment
Title :write a script find count of user id between the range
Date :27/07/1998
author: karthik
input :1 100
output: count of user id btw the range 33
comment
#!/bin/bash

a=`cat /etc/passwd | cut -d ":" -f4`    #assign user id to variable  
arr=($a)                                  #then as array
l=`expr ${#arr[@]}  - 1 `
count=0
if [ $# -eq 0 ]                            #condition to check argument
then
for i in `seq 0 $l`                        #loop to execute within range
do
		if [ ${arr[$i]} -gt 500  -a ${arr[$i]} -lt 100000 ] #default range
		then
			
		count=`expr $count + 1 `
fi
done
echo default total count of user id between 500 and 100000 is  $count
elif [ $# -eq 1 ]
then      
		echo  enter valid argument! want to enter another argument 
else      
 for i in `seq 0 $l`
 do
		if [ ${arr[$i]} -gt $1 -a  ${arr[$i]} -lt  $2  ]   #range by user
		then
				
				count=`expr $count + 1`
		fi
done
fi
echo  total  count of user id between  $1 and $2 is $count 

