#!/bin/bash
<<comment
# TITTLE  : write to script to delete swap files
# DATE    :27/07/2019
# AUTHOR  :karthik
# INPUT   :
# OUTPUT  :
comment

files=`find *.swp`										# swp files are assigned to files
if [ ${#files} -eq 0 ]									# check the condition
		then
		echo there is no swap files						
		else
				rm *.swp								#remove .swp files
				fi
