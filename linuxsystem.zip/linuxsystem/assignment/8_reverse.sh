<<coment
#title:write a script to pritn a number in reverse
#date:22.7.19
#author:karthik
#input:123
#ouput:321
coment
#!/bin/bash

rev=0  #to assign value to rev variable
num=$1
if [ $# -eq 0 ]   #condition to check for argument
then
		echo enter the valid argument
else
		while [ $num -ne 0 ]   #condition till value reach value 0
		do
				digit=`expr $num % 10`  #to divide and get reminder
				rev=`expr $rev \* 10 + $digit`      #to add the digit to the reverse value
				num=`expr $num / 10`     #to divide the digit individually
		done
		echo reverse $rev
fi
