#!/bin/bash
echo  enter the value
read n
for ((i=1;i<=n;i++))
do
	for ((j=1;j<=i;j++,k++))
		do

if [ $k -eq 0 ]
	then
	echo -n "0"
	else
	echo -n "1"
	fi
done	
echo -e " "
done


