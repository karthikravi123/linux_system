<<coment
#title:to print n numbers
#date:20.7.19
#author:karthik
#input:10
#output:8
coment



#!/bin/bash
n=$1              #to pass argument in command line
a=0 b=1 
if [ $# -eq 0 ]       #conditon for argument
then
		echo enter the  valid argument
else
		echo fib series $a  
echo  $(($a + $b))
	for (( i=1;i<=n;i++))        #for condition for series to add
		do
			c=$(($a + $b))            #swap methodd
			a=$b
			b=$c	
			
			
if [ $c -lt $n ]
		then
				echo $c 
			fi
done
fi
