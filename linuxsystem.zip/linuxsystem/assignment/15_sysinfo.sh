<<coment
#title: write a script to print following 

#      1 currently logged user
#	  2 your shell directory
#	  3 home directory
#	  4 os name &version
#	  5 current working directory
#	  6 no of users logged in
#	  7 show all available shells in your system
#	  8 hard disk information
#	  9 cpu information
#	  10 memory information
#	  11 file system information
#	  12 currently running process"
#date:22.7.19
#author:karthik
#input:
#output
coment
#!/bin/bash
echo "    the option are 
      1 currently logged user
	  2 your shell directory
	  3 home directory
	  4 os name &version
	  5 current working directory
	  6 no of users logged in
	  7 show all available shells in your system
	  8 hard disk information
	  9 cpu information
	  10 memory information
	  11 file system information
	  12 currently running process"
	  read m
	  case ${m} in
	  1) echo $(whoami) 
	    ;; 
	  2) echo  $SHELL
	    ;;
	  3) echo  $HOME 
		;;
	  4) echo " $(lsb_release -a) " 
		;;
	  5) echo "$(pwd) " 
		;;
	  6) echo " $(who)" 
		;;
      7) echo $(cat /etc/shell) 
		 ;;	  
	  8) echo $(lshw)
		;;
	  9) echo $(lscpu)
		;;
	  10) echo $(vmstat -s)
		;;	  
	  11) echo $(df -h)
		;;
	  12) echo $(ps -a) 
		;;
*) echo enter the valid  value
	     esac
