<<coment
#title:sort a given numebr in ascending or descending order
#date:22.7.19
#author:karthik
#input: 5 4 3 2 1
#output:1 2 3 4 5
coment
#!/bin/bash
if [ $# -eq 0 ]
then
		echo enter valid argument
else

		arr=($@) #to store array
		echo ${arr[@]}
		echo enter option 1.ascending 2.descending  #option to select 
		read n
		l=`expr ${#arr[@]} - 1`  #to decrement one by one 
		#echo length is $l
		echo select option $n
		if [ $n -eq 1 ]          #condition for option
		then
				for i in $(seq 0 $l) #for 1 seq to loop	
				do
						for j in $(seq $i $l)  #for comparing two sequence
						do
								temp=0
								if [ ${arr[$i]} -gt ${arr[$j]} ]   #to check each value
								then
										temp=${arr[$i]}        #swapping method if the value is greater
										arr[$i]=${arr[$j]}
										arr[$j]=$temp
								fi
						done
				done
				for i in $(seq 0 $l)     #for printing the value in ascending order
				do
						echo ${arr[$i]}
				done
		else
				for i in $(seq 0 $l) #for sequence used for descending order
				do
						for j in $(seq $i $l)    #for comparing the sequence with other seq
						do
								if [ ${arr[$i]} -lt ${arr[$j]} ]
								then
										temp=${arr[$i]}
										arr[$i]=${arr[$j]}
										arr[$j]=$temp
								fi
						done
				done
				for i in $(seq 0 $l)    #for (( i=0;i<=$l;i++))
				do
						echo ${arr[$i]}
				done
		fi
fi
