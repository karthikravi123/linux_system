#title:to 
#author:karthik
#date:20.7.19
#input:HELLO
#ouput:hello


#!/bin/bash


for  i in *
do
					if [ -f $i ]
					then
			echo $i | tr '[a-z]' '[A-Z]' #for upper case
	elif [ -d $i ]
	then
			echo $i | tr '[A-Z]' '[a-z]'  #for lower case
	fi
	done
			
