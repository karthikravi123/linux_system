<<comment
tiile:write a script to determine whether file system mounted or not
author:karthik
Date :26/07/2019
input:/dev/loop1
output:file system /dev/loop1 is 100% used with 0 spaces
comment


#!/bin/bash
str=$(df --output=source)        #assign filesystem to str
str1=$(df --output=pcent | cut -d "%" -f1)  #assign percent  to str
str2=$(df --output=avail)
str3=$(df --output=target)
arr=($str)                # assign  string  to array
arr1=($str1)
arr2=($str2)
arr3=($str3)
if [ $# -ne  1 ]
then 
		echo enter any file syystem in argument
else 
		#assign string to array
		return=0
		l=`expr ${#arr[@]} - 1`    #length  
		for i in `seq 1  $l`
		do
		if [ "${arr[$i]}" = $1 ]    #condition to check available is or not 
				then

						echo it is mounted       
						echo file system ${arr[$i]} is ${arr1[$i]} used with ${arr2[$i]}  mounted on ${arr3[$i]}
						return=1	
				fi
		done

		if [ $return -eq 1 ]
		then
				return=0
		else
				echo it is not mounted
		fi
fi
