#!/bin/bash

echo $(sed -i '/^$/d' $1)
