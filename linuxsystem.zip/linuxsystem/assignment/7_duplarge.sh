#!/bin/bash

echo array element recieved
arr=($@)
l=`expr ${#arr[@]} - 1`
echo `expr $l + 1 `
max=${arr[0]}

for ((i=0;i<=$l;i++))
	do
echo
echo
echo "${arr[$i]}"
if [ ${arr[$i]} -gt $max ]
then
max=${arr[$i]}
fi
done
echo  maximum $max


