 #!/bin/bash


 echo -n "enter two no :"
 read a b
echo choice " 1.additon 
              2.subtraction  
			  3.multiplication 
			  4.division"

read n
case ${n} in
1) echo additon `expr "$a + $b" |bc`
;;
2) echo subtraction `expr  "$a - $b" |bc`
;;
3) echo division "scale=0.2 `expr "$a \* $b " |bc `"
;;
4)echo multiplication `expr "$a * $b "|bc`
;;
*) echo "you entered a wrong no plz enter the valid number"
;;
esac



