<<coment
#title:write a script for addition of two no
#date:22.7.19
#author:karthik
#input:10 20
#output:30
coment

#!/bin/bash
echo "enter the two no :"
read a b
echo " $a + $b "| bc
