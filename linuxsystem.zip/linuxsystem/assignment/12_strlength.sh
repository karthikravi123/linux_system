<<coment
#title:to print length of each element
#date:20.9.19
#author:karthik
#input:hello hai
#output:hello=5 
#       hai=3
coment
#!/bin/bash

arr=($@)  #Store the value in array
if [ $# -eq 0 ]
then 
		echo enter the valid string
	else
l=`expr ${#arr[@]} - 1`  #to decrement the value of array 1 by 1
for i in $(seq 0 $l)  #to loop each and every value of string
do
echo  length of string is ${arr[$i]}  ${#arr[$i]} #to print the value of each string
done
fi
