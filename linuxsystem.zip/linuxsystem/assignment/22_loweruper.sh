#title:to convert string lower to upper
#author:karthik
#date:20.7.19
#input:HELLO
#ouput:hello



#!/bin/bash
arr=($@)    #to store th e string
if [ $# -eq 0 ]    #to check for the argument
then 
		echo enter the valid argument
else
 echo select the option 1 for lower and  2 for upper
 read  n
					if [ $n -eq 1 ]
					then
			echo ${arr[@]} | tr '[A-Z]' '[a-z]' #for upper case
	else
			echo ${arr[@]} | tr '[a-z]' '[A-Z]'  #for lower case
	fi
	fi
			
