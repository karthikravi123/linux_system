<<coment
#title:write a script for arithematic calculator using CLI
#date:22.7.19
#author:karthik
#input:25 + 41
#output:30

coment

#!/bin/bash
if [ $# -ne 3 ]    #to check given argument valid or not
then
		echo enter valid argument
else
		case $2 in       #to select arithematic operation
				+)sum=`echo $1 + $3 | bc ` #to add the operation
						echo $sum
						;;
				-) sub=`echo $1 - $3 | bc` #for subtraction
						echo $sub
						;;
				/) div=`expr "scale=02 ; $1 / $3" | bc ` #for subtraction
						echo $div  
						;;
				x) mul=`echo  $1 \* $3 | bc ` #for multiplaction
						echo $mul
						;;
				*)echo select valid operation #to select valid opertaion
		esac
fi



