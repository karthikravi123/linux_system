<<comment
title:random password
author:karthik
date:26.7.19
input:
output:
comment

#!/bin/bash

for i in $(seq 1 8)      #for 8 letters
do
cat /dev/urandom | tr -cd 'a-zA-Z0-9!@#$%^&*()' | fold -w8 | head -n1
done
