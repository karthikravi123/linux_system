<<coment
#title:read n and print great fibonacci number
#date:22.7.19
#auhtor:karthik
#input:10
#output :8
coment
#!/bin/bash

echo -n enter the limit for fib series:
read n     #to read the value
if [ $n -eq 0 ]   #to check for argument
then
		echo enter the valid argument
else 
first=1 second=0 
l=`expr $n - 1`   #to check for max value for iteration
echo $third
third=`expr $first + $second` #to add value
	for i in $(seq 1 $l)
		do
				first=$second    #swapping
				second=$third
				third=`expr $first + $second`
if [ $third -lt $n ]  #condition to check max value
		then
		a=$third  #if max value
			fi
done
fi
echo  greatest val is $a

