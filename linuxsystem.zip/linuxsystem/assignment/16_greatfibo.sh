#!/bin/bash
n=$1
a=0 b=1 

echo fibonaci series $c=$(($a + $b))
	for (( i=1;i<=n;i++))
		do
			c=$(($a + $b))
			a=$b
			b=$c	
			
			
if [ $c -lt $n ]
		then
				echo $c 
			fi
done
