<<comment
title:to search element
author:karthk
date:27.7.19
input:root
output: present
comment


#!/bin/bash

arr=(`cut -d: -f1 /etc/passwd`) #to store in array
#str=($arr)
echo ${arr[@]} #to display
return=0
echo enter the user you want to search
read m
l=`expr ${#arr[@]} - 1`        #to decrement
for i in $(seq 0  $l)
do
		if [ ${arr[$i]} =  $m ]         #if equal then return
		then
        	return=1
		fi
done
echo $return
if [ $return -eq  1 ]    #to print the value present or not
then
		echo $m  prsent
		return=0
else
		echo $m not present
fi


