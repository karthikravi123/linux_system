#!/bin/bash

h=`date +%H`
a=`date`
b=`date +%S`
c=`date +%M`
k=`expr $h:$b:$c`
l=`whoami`
#echo $l
if [ $h -gt 5 -a $h -lt 12 ]
then
		echo "good morning $l,Have a nice day!"
		echo this is $a "($k)" 
elif [ $h -gt 12 -a $h -lt 13 ]
		then
				echo "good noon $l,have a nice day!"
				echo this is $a "($k)"
		elif [ $h -gt 13 -a $h -lt 15 ]
		then
			echo "good afternoon $l,have a nice day!"
			echo this is $a "($k)"
	elif [ $h -gt 15 -a $h -lt 21 ]
	then
			echo "goodevening $l,have a nice day!"
			echo this is $a "($k)"
	else [ $h -gt 21 -a $h -lt 5 ] 
			echo "good night $l,Have a nice daY!"
		    echo  this is  $a "($k)" 
	fi
