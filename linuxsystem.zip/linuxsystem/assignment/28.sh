<<comment
title:recursion function
author:karthik
date:29.7.19
input:
output:
comment



#!/bin/bash

if [ $# -lt 1 ] #to check for argument
then
		echo "invalid argumment"
else
		arr=($@)     #to store array
		count=0
		function num()  #function syntax
		{
				if [ $count -ge ${#arr[@]} ]  #to check for count
				then
				return
				fi
				echo ${arr[$count]}  #to print value
				let count=$(($count+1))
				num 
		}
		num 

fi
