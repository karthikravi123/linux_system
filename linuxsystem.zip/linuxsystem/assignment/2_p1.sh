<<coment
#title : Read 'n' and generate the pattern given below
#date : 22.7.19
#author: karthik.R
#input:5
#output:  1
#         1 2     
#         1 2 3
#		  1 2 3 4
#		  1 2 3 4 5

coment

#!/bin/bash

echo "read the value of n "
read n

for i in $(seq 1 $n)            #loop for row 
do
		for j in $(seq 1 $i)      #loop for coloumn
		do
				echo -n " $j"   #for value
		done
		echo " "
done

