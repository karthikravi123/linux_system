<<coment
#title: Read 'n' and generate the pattern
#date:22.7.19
#author:karthik 
#input:5
#output: 1
#        2 3
#        4 5 6
#        7 8 9 10
#        11 12 13 14 15
coment


#!/bin/bash

echo "read the value of n "
read n
k=0
for i in $(seq 1 $n)    #for loop to  print i value
do
		for j in $(seq 1 $i)   #for loop to print the value
		do
				k=(`expr $k + 1`)
				echo  -n " $k"
		done
		echo  -e " "
done
