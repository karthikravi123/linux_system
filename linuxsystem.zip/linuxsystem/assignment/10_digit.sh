<<coment
#title:write a script to perform arithmetic operation on digit of a givn no
#date:22.7.19
#author:karthik
#input:1234+
#output:9
coment
#!/bin/bash

echo -n  "enter a string"
read str
if [ ${#str[i]} -eq 0 ]
then
		echo enter valid argument
else

		l=`expr ${#str} - 1`  #to iterate each number
		for i in $(seq 0 $l)   #to loop  till value  l
		do
				arr[i]=${str:$i:1}   #to get the each value 1 by 1
		done
		res=${arr[0]} # to store the value of array
		n=`expr $l - 1`
		for j in $(seq 1 $n)  #loop for arithematic operation
		do
				case ${arr[$l]} in  #to select the case
						"+") res=`echo  $res + ${arr[$j]} | bc` #for addition
								;;
						"-") res=`echo $res - ${arr[$j]} | bc` #for subtraction
								;;
						"x") res=`echo $res \* ${arr[$j]} | bc` #for multiplication
								;;
						"/") res=`echo " scale=02; $res / ${arr[$j]}"| bc` #division
								;;
						"%") res=`echo $res % ${arr[$j]} | bc`  #for modular
								;;
								*) echo enter the valid argument
								;;
				esac
		done
		echo value  is $res
fi
