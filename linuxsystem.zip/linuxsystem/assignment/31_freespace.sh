#write a script to print file sysytem less than 10% free space
#author:karthik 
#Date:31/07/2019
#input:df -h
#output:filesytem les than 10 %usage

#!/bin/bash
str=$(df --output=source)        #assign filesystem to str
str1=$(df --output=pcent | cut -d "%" -f1)  #assign percent  to str

arr=($str)                # assign  string  to array
arr1=($str1)              #assign string to array
l=`expr ${#arr[@]} - 1`    #length  
for i in `seq 1  $l`    
do
		if [ ${arr1[$i]} -gt 90 ]    #condition to check available %
		then 
				echo file system ${arr[$i]} is less than 10 %		
		fi
done
