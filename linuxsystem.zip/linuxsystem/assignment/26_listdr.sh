#title:to list directory
#author:karthik
#date:26.7.19
#input:
#output:

#!/bin/bash

path=($@)

if [ 
