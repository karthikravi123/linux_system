 #!/bin/bash
if [ $# -ne 3 ]
		then
	echo enter valid argument
	else
	case ${2} in
+)echo sum=`expr $1 + $3 |bc`
;;
-)echo sub=`expr $1 - $3 |bc`
;;
/)echo  div=`expr"scale=0.2 $1 / $3" |bc `
;;
x)echo mul=`expr $1 \* $3 `
;;
esac
fi

echo $sum
