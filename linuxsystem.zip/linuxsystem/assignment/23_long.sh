<<comment
title:to display long and short name
author:karthik
date:22.7.19
input:
output:

comment

#/bin/bash
#user=` cat /etc/passwd | cut -d : -f1 `
#arr=($user)
arr=(`cut -d: -f1 /etc/passwd`)
#echo ${arr[@]}

l=`expr ${#arr[@]} - 1`
a=${#arr[0]}
b=${#arr[0]}
for i in $(seq 1 $l)
do
		if [[ $a -lt ${#arr[$i]} ]]
		then
				max=${arr[$i]}
				a=${#arr[$i]}

		elif [[ $b -gt ${#arr[$i]} ]]
		then 
				min=${arr[$i]}
				b=${#arr[$i]}
		fi

done

echo
echo long $max
echo short $min

