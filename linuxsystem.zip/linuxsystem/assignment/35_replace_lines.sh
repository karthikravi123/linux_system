<<comment
write a script to to delete a random line insert a pattern
authur: karthik
date:30/7/2019
input:random lines
output:<-----deleted----->
comment
#!/bin/bash
a=$1
f=`cat $a | wc -l`         #taking total no of lines in file
b=$(($f * 20 / 100 ))        #20% of lines
c="<--deleted-->"
#echo $b
for i in `seq 1 $b`          #loop upto 20% of line        
do
	randomline=$((1+$RANDOM%$f))  #random lines (1-totalines)
		
if [ $randomline != $c ]
then          #replacing random lines to deleted pattern
    sed -i  ''${randomline}'s/.*/<--deleted-->/' $a
	
echo linenumber:$randomline
  fi				 

done 
cat $a          #showing file contents
