#title:sort the given number in ascending or descending order
#date:22.7.19
#author:karthik
#input:5 4 3 2 1
#output:1 2 3 4 5


#!/bin/bash


arr=($@)
echo ${arr[@]}
echo enter option 1.ascending 2.descending
read n
l=`expr ${#arr[@]}-1`
#echo length is $(($l+1))

if [ $n -eq 1 ]
then
for ((i=0;i<=$l;i++))
do
for ((j=$i;j<=$l;j++))
do
if [ ${arr[$i]} -gt ${arr[$j]} ]
then
temp=${arr[$i]}
arr[$i]=${arr[$j]}
arr[$j]=$temp
fi
done
done
for (( i=0;i<=$l;i++))
		do
echo ${arr[$i]}
done
else
for ((i=0;i<=$l;i++))
do
for ((j=$i;j<=$l;j++))
do
if [ ${arr[$i]} -lt ${arr[$j]} ]
then
temp=${arr[$i]}
arr[$i]=${arr[$j]}
arr[$j]=$temp
fi
done
done
for (( i=0;i<=$l;i++))
		do
echo ${arr[$i]}
done
fi
