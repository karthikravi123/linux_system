#!/bin/bash


echo How many times
read n
for i in $(seq 1 $n)
		do
				echo enter the number
				read arr[$i]
				done
